/*
MyOpenLab by Carmelo Salafia www.myopenlab.de
Copyright (C) 2004  Carmelo Salafia cswi@gmx.de

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


package VisualLogic;

import java.awt.*;
import java.io.File;
import java.net.*;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Properties;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.text.html.*;
/**
 *
 * @author  Homer
 */
public class FrameInfo extends javax.swing.JDialog {
    
    private JFrame parent;
    private String elementPath;
            
    private String addPoints(String str)
    {
        String result="";
        for (int i=0;i<str.length();i++)
        {            
            char ch=str.charAt(i);
            
            if (ch!='.')  
            {
                result+=ch+"."; 
            }else 
            {
                //result+=ch;
            }
        }
        return result;                
    }
    
    
    private void fillTable()
    {
        

    DefaultTableModel model = new DefaultTableModel()
    { 
        public boolean isCellEditable(int row, int column) 
        { 
             return false; 
        } 
    };         
        
        model.addColumn("Name");
        model.addColumn("Value");
        Properties props=System.getProperties();
        
        Enumeration items=props.propertyNames();

        while(items.hasMoreElements())
        {
            String key=items.nextElement().toString();
            //System.out.println(key+" , "+System.getProperty(key));
            String[] item = new String[2];
            item[0]=key;
            item[1]=System.getProperty(key);
            model.addRow(item);
        }

        jTable1.setModel(model);
        
        
    }
    
    /** Creates new form frmInfo */
    public FrameInfo(JFrame parent, boolean modal, String elementPath) {
        super(parent, modal);
        initComponents();
        
        this.elementPath=elementPath;
        this.parent=parent;
        
        
        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((screenSize.width-getWidth())/2, (screenSize.height-getHeight())/2);       
                
        //jLabel4.setText(Version.strApplicationTitle);
        
        jButton3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        
        java.awt.event.ActionListener actionListener = new java.awt.event.ActionListener() 
        {
          public void actionPerformed(java.awt.event.ActionEvent actionEvent) 
          {                
                dispose();            
          }
        };
        
        javax.swing.KeyStroke stroke = javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0);
        rootPane.registerKeyboardAction(actionListener, stroke, javax.swing.JComponent.WHEN_IN_FOCUSED_WINDOW);
        
        
        jLabelVers.setText(Version.strApplicationVersion+ " "+Version.strStatus);
        
        
        fillTable();
        
        
        listDrivers();
        
        /*jLabelVersion.setText(System.getProperty("java.version"));
        
        jLabelBetriebssystem.setText(System.getProperty("os.name")+" version "+System.getProperty("os.version")+ " running on "+System.getProperty("os.arch"));
        jLabelVM.setText(System.getProperty("java.vm.name")+" version"+System.getProperty("java.vm.version"));
        jLabelVendor.setText(System.getProperty("java.vm.vendor")); 
        jLabelJavaHome.setText(System.getProperty("java.home")); 
        jLabelUserHome.setText(System.getProperty("user.home")); */
            
        try
        {              
            Locale loc = Locale.getDefault();
            String strLocale=loc.toString();
            
            URL url = null;
            
            if (strLocale.equalsIgnoreCase("de_DE"))
            {
                url = getClass().getResource("/VisualLogic/license.txt");
            }else
            if (strLocale.equalsIgnoreCase("en_US"))
            {
                url = getClass().getResource("/VisualLogic/license.txt");
            }else
            if (strLocale.equalsIgnoreCase("es_ES"))
            {
                url = getClass().getResource("/VisualLogic/license.txt");
            }
            
            jEditorPane1.setContentType("text/html");
            jEditorPane1.setPage(url);
            
        } catch (Exception ex) 
        {            
            Tools.showMessage("Liesmich.html wurde nicht gefunden!");
        }
        
        jEditorPane1.addHyperlinkListener (
        new HyperlinkListener () {
      public void hyperlinkUpdate(HyperlinkEvent e) {
        // Das aendern des Mauszeigers geht ab 
        // Java 1.3 auch automatisch 
        if (e.getEventType() == 
                           HyperlinkEvent.EventType.ENTERED) {
           ((JEditorPane) e.getSource()).setCursor(
              Cursor.getPredefinedCursor(
                  Cursor.HAND_CURSOR));
        } else
          if (e.getEventType() == 
                           HyperlinkEvent.EventType.EXITED) {
           ((JEditorPane) e.getSource()).setCursor(
               Cursor.getPredefinedCursor(
                  Cursor.DEFAULT_CURSOR));
          } else
           // Hier wird auf ein Klick reagiert
            if (e.getEventType() == 
                              HyperlinkEvent.EventType.ACTIVATED) {
              JEditorPane pane = (JEditorPane) e.getSource(); 
              if (e instanceof HTMLFrameHyperlinkEvent) {
                HTMLFrameHyperlinkEvent evt = 
                                       (HTMLFrameHyperlinkEvent)e;
                HTMLDocument doc = 
                     (HTMLDocument)pane.getDocument();
                doc.processHTMLFrameHyperlinkEvent(evt);
              } else try {
                       // Normaler Link
                       pane.setPage(e.getURL());
                     } catch (Throwable t) {
                         t.printStackTrace();
                     }
            }
       }
      });

    }
    
    
    public void listDrivers()
    {
        
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
        
        while(model.getRowCount()>0) model.removeRow(0);

        for (int i=0;i<model.getColumnCount();i++)
        {
            TableColumn col = jTable2.getColumnModel().getColumn(i);            
            col.setPreferredWidth(150);            
        }
        
        
        String driverPath=elementPath+"/Drivers";
        
        File[] files=new File(driverPath).listFiles();
        
        for (int i=0;i<files.length;i++)
        {
            File f=files[i];
            if (f.isDirectory())
            {
                DriverInfo info=Tools.openDriverInfo(f);
                
                if (info!=null)
                {                    
                    String[] item = new String[5];
                    item[0]=f.getName();
                    item[1]=info.Copyrights;
                    item[2]=info.Website;
                    item[3]=info.Lizenz;
                    item[4]=new File( driverPath+"/"+f.getName() ).getAbsolutePath();
                    
                    
                    model.addRow(item);                   
                }
            }
        }
        // End Loading Drivers.
        
    }
 
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jEditorPane1 = new javax.swing.JEditorPane();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jEditorPane2 = new javax.swing.JEditorPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextPane2 = new javax.swing.JTextPane();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabelVers = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jToggleButton1 = new javax.swing.JToggleButton();
        jToggleButton2 = new javax.swing.JToggleButton();
        jToggleButton3 = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("VisualLogic/FrameInfo"); // NOI18N
        setTitle(bundle.getString("Titel")); // NOI18N
        setBackground(java.awt.SystemColor.control);
        setResizable(false);

        jButton1.setText(bundle.getString("close")); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jScrollPane1.setAlignmentX(0.0F);

        jEditorPane1.setBorder(null);
        jEditorPane1.setEditable(false);
        jEditorPane1.setFont(new java.awt.Font("Arial", 0, 10));
        jEditorPane1.setPreferredSize(new java.awt.Dimension(100, 100));
        jScrollPane1.setViewportView(jEditorPane1);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab(bundle.getString("Lizenz"), jPanel5); // NOI18N

        jEditorPane2.setEditable(false);
        jEditorPane2.setText("MyOpenLab project initiator: Carmelo Salafia (cswi@gmx.de)\nhttp://www.myopenlab.de\nIf you modify the myopenlab sourcecode, please send it to cswi@gmx.de\nso i can publish it under www.myopenlab.de.\n\nIf some Elements don't possess sourcecode you can request it by email.\n\nlooks is under BSD License see http://www.opensource.org/licenses/bsd-license.php\nhttps://looks.dev.java.net/\n\n\nThis Programm use pictures from www.photocase.com.\n\nSome Icons from:\n+ Tango Project : http://tango.freedesktop.org\n+ mini icons - famfamfam.com\n\nRXTX Library LGPL License \nfrom http://users.frii.com/jarvi/rxtx/");
        jScrollPane2.setViewportView(jEditorPane2);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab(bundle.getString("Copyrights"), jPanel7); // NOI18N

        jTextPane2.setEditable(false);
        jTextPane2.setText(bundle.getString("contributor")); // NOI18N
        jScrollPane4.setViewportView(jTextPane2);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab(bundle.getString("contributors"), jPanel2); // NOI18N

        jPanel6.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        jPanel6.setLayout(new java.awt.BorderLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Name", "Value"
            }
        ));
        jScrollPane3.setViewportView(jTable1);

        jPanel6.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab(bundle.getString("Java_Details"), jPanel6); // NOI18N

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"AAAAAAAAAAAAAAAAAAAAAA", "CCC", "ERRR", null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Module", "Copyrights", "Website", "license", "Path"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane5.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Drivers", jPanel1);

        jLabel6.setText("Build :");
        jLabel6.setAutoscrolls(true);

        jLabelVers.setFont(new java.awt.Font("Arial", 0, 10));
        jLabelVers.setText("XX.XX");

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/top.png"))); // NOI18N
        jButton2.setBorderPainted(false);
        jButton2.setDefaultCapable(false);
        jButton2.setFocusPainted(false);
        jButton2.setFocusable(false);
        jButton2.setPreferredSize(new java.awt.Dimension(500, 79));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/icon_2.png"))); // NOI18N
        jButton3.setToolTipText("www.MyOpenLab.de");
        jButton3.setBorderPainted(false);
        jButton3.setFocusPainted(false);
        jButton3.setFocusable(false);
        jButton3.setPreferredSize(new java.awt.Dimension(56, 41));
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });

        jToggleButton1.setBackground(new java.awt.Color(255, 255, 255));
        jToggleButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/lgplv3-88x31.png"))); // NOI18N
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jToggleButton2.setBackground(new java.awt.Color(255, 255, 255));
        jToggleButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/gplv3-88x31.png"))); // NOI18N
        jToggleButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton2ActionPerformed(evt);
            }
        });

        jToggleButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bilder/netBeans.gif"))); // NOI18N
        jToggleButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(219, 219, 219))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 494, Short.MAX_VALUE)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 494, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelVers, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jToggleButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jToggleButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jToggleButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jToggleButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jToggleButton3)
                                    .addComponent(jToggleButton2, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(8, 8, 8))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabelVers))
                                .addGap(18, 18, 18))))
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jButton3MouseClicked
    {//GEN-HEADEREND:event_jButton3MouseClicked
        Tools.openUrl(parent,"http://www.myopenlab.de"); 
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jToggleButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton2ActionPerformed
        Tools.openUrl(parent,"http://www.gnu.org/licenses/licenses.html"); 
    }//GEN-LAST:event_jToggleButton2ActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
       Tools.openUrl(parent,"http://www.gnu.org/licenses/licenses.html"); 
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void jToggleButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton3ActionPerformed
        Tools.openUrl(parent,"http://www.netbeans.org"); 
    }//GEN-LAST:event_jToggleButton3ActionPerformed
    

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JEditorPane jEditorPane1;
    private javax.swing.JEditorPane jEditorPane2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabelVers;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextPane jTextPane2;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JToggleButton jToggleButton2;
    private javax.swing.JToggleButton jToggleButton3;
    // End of variables declaration//GEN-END:variables
    
}
