//*****************************************************************************
//* Element of MyOpenLab Library                                              *
//*                                                                           *
//* Copyright (C) 2014  Carmelo Salafia (cswi@gmx.de)                         *
//*                                                                           *
//* This library is free software; you can redistribute it and/or modify      *
//* it under the terms of the GNU Lesser General Public License as published  *
//* by the Free Software Foundation; either version 2.1 of the License,       *
//* or (at your option) any later version.                                    *
//* http://www.gnu.org/licenses/lgpl.html                                     *
//*                                                                           *
//* This library is distributed in the hope that it will be useful,           *
//* but WITHOUTANY WARRANTY; without even the implied warranty of             *
//* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                      *
//* See the GNU Lesser General Public License for more details.               *
//*                                                                           *
//* You should have received a copy of the GNU Lesser General Public License  *
//* along with this library; if not, write to the Free Software Foundation,   *
//* Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110, USA                  *
//*****************************************************************************

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import VisualLogic.*;
import VisualLogic.variables.*;
import tools.*;

import java.awt.*;

import java.io.*;
import java.nio.channels.*;
import java.nio.*;
import javax.swing.*;

public class Firmata extends JVSMain implements MyOpenLabDriverOwnerIF {

    int inputPins = 0;
    int outputPins = 0;

    public int digitalOutputData = 0;

    private Image image;

    String lines[] = null;

    private MyOpenLabDriverIF driver;

    private VSPropertyDialog text = new VSPropertyDialog();
    private VSPropertyDialog capatibilities_button = new VSPropertyDialog();

    private VSString textVar = new VSString(";");

    

    VS1DByte inBytes = new VS1DByte(1);

    private javax.swing.Timer timer;

    private VSInteger pollTime = new VSInteger(200);

    private VSObject in[];
    private int[] inPinNumbers;
    private String[] inPinType;

    private VSObject out[];
    private int[] outPinNumbers;
    private String[] outPinType;

    boolean debug = true;

    int command = 0;
    int needParams = 0;
    int params[] = new int[500];
    int counter = 0;

    public ArrayList<PinCapatibilities> capatibilities = new ArrayList();
    
    private VSString comport = new VSString("");
    private VSInteger baud=new VSInteger(9600);
    private VSInteger bits=new VSInteger(8);
    private VSInteger parity=new VSInteger(0);
    private VSInteger stopBits=new VSInteger(1);

    public void pinMode(int pin, int mode) {

        inBytes.setBytes(new byte[]{
            (byte) (0xF4),
            (byte) (pin),
            (byte) (mode)});

        if (driver != null) {
            if (debug) {
                System.out.println("PINMODE(" + pin + " , " + mode + ")");
            }
            driver.sendCommand(comport.getValue() + ";SENDBYTES", inBytes);
        }
    }

    /* public void reportPin(int pin) {
     inBytes.setBytes(new byte[]{
     (byte) (0xD0 + (pin - 2)),
     (byte) (0x01)
     });
     if (driver != null) {
     if (debug) {
     System.out.println("REPORTPIN(" + pin + ")");
     }
     driver.sendCommand(comport.getValue() + ";SENDBYTES", inBytes);
     }
     }*/
    public void reportPin(int pin) {

        inBytes.setBytes(new byte[]{
            (byte) (0xD0 + (pin - 2)),
            (byte) (0x01),});
        if (driver != null) {
            if (debug) {
                System.out.println("REPORTPIN(" + pin + ")");
            }
            driver.sendCommand(comport.getValue() + ";SENDBYTES", inBytes);
        }
    }

    public void reportAnalogPin(int pin) {

        inBytes.setBytes(new byte[]{
            (byte) (0xC0),
            (byte) (0x01),});
        if (driver != null) {
            if (debug) {
                System.out.println("reportAnalogPin(" + pin + ")");
            }
            driver.sendCommand(comport.getValue() + ";SENDBYTES", inBytes);
        }
    }

    public void analogWrite(int pin, int value) {

        inBytes.setBytes(new byte[]{
            (byte) (Constanten.ANALOG_MESSAGE | (pin & 0x0F)),
            (byte) (value & 0x7F),
            (byte) (value >> 7)});

        if (driver != null) {
            driver.sendCommand(comport.getValue() + ";SENDBYTES", inBytes);
        }

    }

    public void digitalWrite(int pin, int value) {
        int portNumber = (pin >> 3) & 0x0F;
        if (debug) {
            System.out.println("digitalOutputData(" + pin + ", " + value + ")" + digitalOutputData);
        }

        // int val = value << (pin - 1);
        if (value == 1) {
            digitalOutputData = digitalOutputData | (1 << (pin - 1));
        } else {
            digitalOutputData = digitalOutputData & ~(1 << (pin - 1));
        }

        if (debug) {
            System.out.println(Constanten.DIGITAL_MESSAGE | portNumber);
        }
        if (debug) {
            System.out.println(digitalOutputData >> 7);
        }
        if (debug) {
            System.out.println(digitalOutputData & 0x7F);
        }

        /*this.out.write(Constanten.DIGITAL_MESSAGE | portNumber);
         this.out.write(Constanten.digitalOutputData[portNumber] & 0x7F);
         this.out.write(Constanten.digitalOutputData[portNumber] >> 7);*/
        inBytes.setBytes(new byte[]{
            (byte) (Constanten.DIGITAL_MESSAGE | portNumber),
            (byte) (digitalOutputData >> 7),
            (byte) (digitalOutputData & 0x7F)});
        if (driver != null) {
            driver.sendCommand(comport.getValue() + ";SENDBYTES", inBytes);
        }

    }

    /* capabilities query
     * -------------------------------
     * 0  START_SYSEX (0xF0) (MIDI System Exclusive)
     * 1  capabilities query (0x6B)
     * 2  END_SYSEX (0xF7) (MIDI End of SysEx - EOX)
     */

    /* capabilities response
     * -------------------------------
     * 0  START_SYSEX (0xF0) (MIDI System Exclusive)
     * 1  capabilities response (0x6C)
     * 2  1st mode supported of pin 0
     * 3  1st mode's resolution of pin 0
     * 4  2nd mode supported of pin 0
     * 5  2nd mode's resolution of pin 0
     ...   additional modes/resolutions, followed by a single 127 to mark the
     end of the first pin's modes.  Each pin follows with its mode and
     127, until all pins implemented.
     * N  END_SYSEX (0xF7)
     */
    public void queryCapatibilities() {

        //VS1DByte inBytes = new VS1DByte(1);
        inBytes.setBytes(new byte[]{
            (byte) 0xF0,
            (byte) 0x6B,
            (byte) 0xf7}
        );

        System.out.println("queryCapatibilities");
        if (driver != null) {
            driver.sendCommand(comport.getValue() + ";SENDBYTES", inBytes);
        }

    }

    //
    //
    // Servo Utils : compound commands for servo piloting ...
    //
    //
	/* 
     * Servo config
     * --------------------
     * 0  START_SYSEX (0xF0)
     * 1  SERVO_CONFIG (0x70)
     * 2  pin number (0-127)
     * 3  minPulse LSB (0-6)
     * 4  minPulse MSB (7-13)
     * 5  maxPulse LSB (0-6)
     * 6  maxPulse MSB (7-13)
     * 7  angle LSB (0-6)
     * 8  angle MSB (7-13)
     * 9  END_SYSEX (0xF7)
     */
    public void setServoConfig(int pinNumber, int minPulse, int maxPulse) {

        /*try {
         byte pin = (byte) (pinNumber & 0xff);

         byte minPulseLSB = (byte) (minPulse & 0xff);
         byte minPulseMSB = (byte) ((minPulse >> 8) & 0xff);

         byte maxPulseLSB = (byte) (maxPulse & 0xff);
         byte maxPulseMSB = (byte) ((maxPulse >> 8) & 0xff);

         //byte angleLSB = (byte) (angle & 0xff);
         //byte angleMSB = (byte) ((angle >> 8) & 0xff);
         this.out.write(new byte[]{
         (byte) 0xf0,
         (byte) 0x70,
         pin,
         minPulseLSB, minPulseMSB,
         maxPulseLSB, maxPulseMSB,
         (byte) 0xf7
         }
         );
         } catch (IOException ex) {
         Logger.getLogger(Firmata.class.getName()).log(Level.SEVERE, null, ex);
         }*/
    }

    public void start_sendCommands() {

        /*try {

         out = serialPort.getOutputStream();
         (new Thread(new SerialWriter(out, this))).start();

         } catch (IOException ex) {
         Logger.getLogger(Firmata.class.getName()).log(Level.SEVERE, null, ex);
         } finally {
         try {
         out.close();
         } catch (IOException ex) {
         Logger.getLogger(Firmata.class.getName()).log(Level.SEVERE, null, ex);
         }
         }*/
    }

    public void paint(java.awt.Graphics g) {
        if (image != null) {
            drawImageCentred(g, image);
        }
    }

    public void onDispose() {
        if (image != null) {
            image.flush();
            image = null;
        }
    }

    public void copyFile(File source, File dest) throws IOException {
        FileChannel in = null, out = null;
        try {
            in = new FileInputStream(source).getChannel();
            out = new FileOutputStream(dest).getChannel();

            long size = in.size();
            MappedByteBuffer buf = in.map(FileChannel.MapMode.READ_ONLY, 0, size);

            out.write(buf);

        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
    }

    public void setPropertyEditor() {

        //element.jAddPEItem("Poll Time[ms]", pollTime, 1, 5000);
        element.jAddPEItem("Capatibilities", capatibilities_button, 0, 0);

        element.jAddPEItem("Config Pins", text, 0, 0);
        element.jAddPEItem("COM Port", comport, 0, 0);

        element.jAddPEItem("Baud", baud, 1, 999999);
        element.jAddPEItem("DataBits", bits, 5, 8);        
        element.jAddPEItem("stopBits", stopBits, 1, 2);
        element.jAddPEItem("Partity", parity, 0, 1);
    }

    public void propertyChanged(Object o) {
        if (o.equals(text)) {
            NewJDialog frm = new NewJDialog(null, true);
            frm.jEditorPane1.setText(textVar.getValue());
            frm.setTitle("Config-Pins");
            frm.setVisible(true);

            if (frm.result) {
                textVar.setValue(frm.text);

                init();
            }
            //loadImage(file.getValue());
        }

        if (o.equals(capatibilities_button)) {

            try {
                start();

                Thread.sleep(10000);

                String str = "";
                for (int i = 0; i < capatibilities.size() - 1; i++) {

                    PinCapatibilities items = capatibilities.get(i);
                    str += "PIN : " + i + "\n";
                    if (items.items.size() == 0) {
                        str += "  Not Supported!\n";
                    } else {
                        for (int j = 0; j < items.items.size(); j++) {
                            PinCapatibilityItem item = items.items.get(j);

                            String type = "";

                            switch (item.pinCapatibility) {
                                case Constanten.PIN_INPUT:
                                    type = "PIN_INPUT";
                                    break;
                                case Constanten.PIN_OUTPUT:
                                    type = "PIN_OUTPUT";
                                    break;
                                case Constanten.PIN_ANALOG:
                                    type = "PIN_ANALOG";
                                    break;
                                case Constanten.PIN_PWM:
                                    type = "PIN_PWM";
                                    break;
                                case Constanten.PIN_SERVO:
                                    type = "PIN_SERVO";
                                    break;
                                default:
                                    type = "Unknown";
                                    break;
                            }

                            str += "  Support : " + type + "\n";

                        }
                    }
                }
                System.out.println(str);
                stop();

                NewJDialog frm = new NewJDialog(null, true);
                frm.setTitle("Capatibilities");
                frm.jEditorPane1.setText(str);
                frm.setVisible(true);

                if (frm.result) {
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(Firmata.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public void init() {

        inputPins = 0;
        outputPins = 0;

        
        lines = textVar.getValue().split(";");

        for (String line : lines) {

            System.out.println("line : " + line);
            String cols[] = line.split("=");

            if (cols.length == 2) {
                String pinType = cols[1].trim().replace("\n", "");

                if (pinType.trim().equalsIgnoreCase("DIGITAL_OUTPUT") || pinType.trim().equalsIgnoreCase("PWM_OUTPUT") || pinType.trim().equalsIgnoreCase("SERVO_OUTPUT")) {
                    inputPins++;
                }
                if (pinType.trim().equalsIgnoreCase("DIGITAL_INPUT") || pinType.trim().equalsIgnoreCase("ANALOG_INPUT")) {
                    outputPins++;
                }
            }
        }

        //showMessage("inputs : " + inputPins + ", Outputs : " + outputPins);
        initPins(0, outputPins, 0, inputPins);
        setSize(32 + 22, 10 + (12 * 10));

        initPinVisibility(false, true, false, true);

        element.jSetInnerBorderVisibility(true);

        int c = 0;

        for (String line : lines) {
            String cols[] = line.split("=");

            if (cols.length == 2) {
                String pinNum = cols[0].trim().replace("\n", "");
                String pinType = cols[1].trim().replace("\n", "");

                if (pinType.trim().equalsIgnoreCase("DIGITAL_INPUT")) {
                    setPin(c, ExternalIF.C_BOOLEAN, ExternalIF.PIN_OUTPUT);
                    element.jSetPinDescription(c, "Out Pin " + pinNum);
                    c++;
                }

                if (pinType.trim().equalsIgnoreCase("ANALOG_INPUT")) {
                    setPin(c, ExternalIF.C_INTEGER, ExternalIF.PIN_OUTPUT);
                    element.jSetPinDescription(c, "Out Pin " + pinNum);
                    c++;
                }

            }
        }
        for (String line : lines) {
            String cols[] = line.split("=");

            if (cols.length == 2) {
                String pinNum = cols[0].trim().replace("\n", "");
                String pinType = cols[1].trim().replace("\n", "");

                if (pinType.equalsIgnoreCase("DIGITAL_OUTPUT")) {
                    setPin(c, ExternalIF.C_BOOLEAN, ExternalIF.PIN_INPUT);
                    element.jSetPinDescription(c, "IN (DIGITAL)" + pinNum);
                    c++;
                }

                if (pinType.equalsIgnoreCase("PWM_OUTPUT")) {
                    setPin(c, ExternalIF.C_INTEGER, ExternalIF.PIN_INPUT);
                    element.jSetPinDescription(c, "IN (PWM)" + pinNum);
                    c++;
                }

                if (pinType.equalsIgnoreCase("SERVO_OUTPUT")) {
                    setPin(c, ExternalIF.C_INTEGER, ExternalIF.PIN_INPUT);
                    element.jSetPinDescription(c, "IN (SERVO)" + pinNum);
                    c++;
                }

            }
        }

        String fileName = element.jGetSourcePath() + "icon.png";
        image = element.jLoadImage(fileName);

        element.jSetCaptionVisible(true);
        element.jSetCaption("Firmata IO Interface");
        setName("Firmata IO Interface");

    }

    @Override
    public void initInputPins() {

        int c = 0;
        in = new VSObject[inputPins];
        inPinNumbers = new int[inputPins];
        inPinType = new String[inputPins];

        //lines = textVar.getValue().split(";");
        for (String line : lines) {
            String cols[] = line.split("=");

            if (cols.length == 2) {
                String pinNum = cols[0].trim().replace("\n", "");
                String pinType = cols[1].trim().replace("\n", "").trim();

                if (pinType.equalsIgnoreCase("DIGITAL_OUTPUT")) {
                    in[c] = (VSBoolean) element.getPinInputReference(outputPins + c);

                    inPinNumbers[c] = Integer.parseInt(pinNum);
                    inPinType[c] = pinType;

                    System.out.println("in[" + c + "]=" + pinType);

                    c++;
                }

                if (pinType.equalsIgnoreCase("PWM_OUTPUT")) {
                    in[c] = (VSInteger) element.getPinInputReference(outputPins + c);

                    inPinNumbers[c] = Integer.parseInt(pinNum);
                    inPinType[c] = pinType;

                    System.out.println("in[" + c + "]=" + pinType);

                    c++;

                }

                if (pinType.equalsIgnoreCase("SERVO_OUTPUT")) {
                    in[c] = (VSInteger) element.getPinInputReference(outputPins + c);

                    inPinNumbers[c] = Integer.parseInt(pinNum);
                    inPinType[c] = pinType;

                    System.out.println("in[" + c + "]=" + pinType);

                    c++;
                }

            }
        }

    }

    @Override
    public void initOutputPins() {
        int c = 0;
        out = new VSObject[outputPins];
        outPinNumbers = new int[outputPins];
        outPinType = new String[outputPins];

        //lines = textVar.getValue().split(";");
        for (String line : lines) {
            String cols[] = line.split("=");

            if (cols.length == 2) {
                String pinNum = cols[0].trim().replace("\n", "");
                String pinType = cols[1].trim().replace("\n", "").trim();

                if (pinType.equalsIgnoreCase("DIGITAL_INPUT")) {
                    //element.setPinOutputReference(c++,taste1);
                    out[c] = new VSBoolean();
                    element.setPinOutputReference(c, out[c]);

                    outPinNumbers[c] = Integer.parseInt(pinNum);
                    outPinType[c] = pinType;

                    System.out.println("out[" + c + "]=" + pinType);

                    c++;
                }

                if (pinType.equalsIgnoreCase("ANALOG_INPUT")) {
                    out[c] = new VSInteger();
                    element.setPinOutputReference(c, out[c]);

                    outPinNumbers[c] = Integer.parseInt(pinNum);
                    outPinType[c] = pinType;

                    System.out.println("out[" + c + "]=" + pinType);

                    c++;
                }
            }
        }
    }

    public boolean started = false;

    public void start() {

        ArrayList<Object> args = new ArrayList<Object>();

        //args.add(new String("COM" + comPort.getValue()));
        args.add(comport.getValue());
        args.add(baud.getValue());
        args.add(bits.getValue());        
        args.add(stopBits.getValue()); 
        args.add(parity.getValue());// No Parity

        args.add(true); // No Parity

        driver = element.jOpenDriver("MyOpenLab.RS232", args);
        driver.registerOwner(this);
        started = true;

        //Thread.sleep(4000);
        //lines = textVar.getValue().split(";");
        //queryCapatibilities();
    }

    public static void showMessage(String message) {
        JOptionPane.showMessageDialog(null, message, "Attention!", JOptionPane.ERROR_MESSAGE);
    }

    public void stop() {
        if (started) {
            started = false;

            if (timer != null) {
                timer.stop();
            }

            //String strCom = "COM" + comPort.getValue();
            String strCom = comport.getValue();

            driver.sendCommand(strCom + ";CLOSE", null);
            element.jCloseDriver("MyOpenLab.RS232");
        }
    }

    public void elementActionPerformed(ElementActionEvent evt) {
        int idx = evt.getSourcePinIndex();
        switch (idx) {
            case 13: {

                /*if (!started && comStart.getValue() == true) {
                 started = true;
                 ArrayList<Object> args = new ArrayList<Object>();

                 //args.add(new String("COM" + comPort.getValue()));
                 args.add(new String(comport.getValue()));
                 args.add(new Integer(57600));
                 args.add(new Integer(8));
                 args.add(new Integer(1));
                 args.add(new Integer(0)); // No Parity
                    
                 driver = element.jOpenDriver("MyOpenLab.RS232", args);
                 driver.registerOwner(this);
                 //timer.start();

                 }*/
            }
            break;
        }
    }

    boolean changed = false;

    public void destElementCalled() {
        if (changed) {
            //outReceived.setValue(false);
            element.notifyPin(1);
            changed = false;
        }
    }

    private void processIn(int input_byte) {
        //int len = values.getLength();

        int cc = input_byte & 0b00000000000000000000000011111111;

        //int cc = this.in.read();
        if (needParams == -1) {
            params[counter++] = cc;

            if (cc == 0xF7) {

                if (params[0] == 0x6C) {

                    capatibilities.clear();

                    PinCapatibilities pin = new PinCapatibilities();
                    capatibilities.add(pin);

                    for (int i = 1; i < counter - 1; i++) {

                        if (params[i] == 127) {
                            pin = new PinCapatibilities();
                            capatibilities.add(pin);

                            continue;
                        }

                        PinCapatibilityItem capatibility = new PinCapatibilityItem();
                        capatibility.pinCapatibility = params[i];
                        capatibility.pinResolution = params[i + 1];
                        i++;
                        pin.items.add(capatibility);

                    }

                    for (int i = 0; i < capatibilities.size() - 1; i++) {

                        PinCapatibilities items = capatibilities.get(i);
                        System.out.println("PIN : " + i);
                        for (int j = 0; j < items.items.size(); j++) {
                            PinCapatibilityItem item = items.items.get(j);

                            System.out.println("Capatibility : " + item.pinCapatibility);

                        }
                    }
                    init();

                    command = 0;
                    counter = 0;
                    needParams = 0;
                } else {

                    // ENDE des Strings                                
                    System.out.println("Version " + params[0] + "." + params[1]);

                    for (int i = 0; i < counter; i++) {
                        System.out.print((char) params[i]);
                    }
                    System.out.println();
                    command = 0;
                    counter = 0;
                    needParams = 0;

                    queryCapatibilities();

                    for (String line : lines) {
                        String cols[] = line.split("=");

                        if (cols.length == 2) {
                            int pinNum = Integer.parseInt(cols[0].trim().replace("\n", ""));
                            String pinType = cols[1].trim().replace("\n", "");

                            if (pinType.trim().equalsIgnoreCase("DIGITAL_OUTPUT")) {
                                pinMode(pinNum, Constanten.PIN_OUTPUT);
                            }
                            if (pinType.trim().equalsIgnoreCase("PWM_OUTPUT")) {
                                pinMode(pinNum, Constanten.PIN_PWM);
                            }
                            if (pinType.trim().equalsIgnoreCase("SERVO_OUTPUT")) {
                                pinMode(pinNum, Constanten.PIN_SERVO);
                            }

                            if (pinType.trim().equalsIgnoreCase("DIGITAL_INPUT")) {
                                pinMode(pinNum, Constanten.PIN_INPUT);

                                reportPin(pinNum);

                            }
                            if (pinType.trim().equalsIgnoreCase("ANALOG_INPUT")) {
                                pinMode(pinNum, Constanten.PIN_ANALOG);

                                reportAnalogPin(pinNum);

                            }
                        }
                    }

                    //owner.start_sendCommands();
                }

            }
        } else if (needParams > 0) {

            needParams--;
            params[needParams] = cc;

            if (needParams == 0) {

                if (command == 0x90) {

                    int valuex = (params[0] << 7) + params[1];

                    boolean isSetPins[] = new boolean[16];

                    for (int i = 0; i < 16; i++) {
                        isSetPins[i] = (valuex & (1 << i)) != 0;
                    }

                    /*System.out.print("Pin Input Value Pins: ");
                     for (int i = 0; i < 16; i++) {

                     System.out.print(isSetPins[i] + ",");
                     }
                     System.out.println();*/
                    for (int i = 0; i < out.length; i++) {

                        int pinNumber = outPinNumbers[i];
                        String pinType = outPinType[i];

                        //System.out.println("Pin.type=" + pinType);
                        if (pinType.equalsIgnoreCase("DIGITAL_INPUT")) {
                            if (out[i] instanceof VSBoolean) {

                                VSBoolean pin = (VSBoolean) out[i];
                                boolean isSet = isSetPins[pinNumber];

                                if (isSet) {
                                    pin.setValue(true);
                                } else {
                                    pin.setValue(false);
                                }
                                element.notifyPin(i);
                                //System.out.println("Pin.setValue(" + pin2 + ")");
                                //System.out.println("Pin.notifyPin(" + pinNumber + ")");
                            }
                        }
                    }

                    //System.out.println("Pin Input Value: " + params[0] + " - " + params[1]);
                    //System.out.println("Pin Input Value: " + params[0] + " - " + params[1]);
                    command = 0;
                    needParams = 0;
                } else if (command >= 0xE0 && command <= (0xE0 + 10)) {

                    int valuex = (params[0] << 7) + params[1];

                    int pinNr = 14 + (command - 0xE0);

                    // System.out.println("Pin Input Analog Pins No " + pinNr + " : " + valuex);
                    for (int i = 0; i < out.length; i++) {

                        int pinNumber = outPinNumbers[i];
                        String pinType = outPinType[i];

                        //System.out.println("Pin.type=" + pinType);
                        if (pinType.equalsIgnoreCase("ANALOG_INPUT")) {
                            if (out[i] instanceof VSInteger) {

                                if (pinNr == pinNumber) {

                                    VSInteger pin = (VSInteger) out[i];

                                    pin.setValue(valuex);

                                    element.notifyPin(i);

                                    //System.out.println("Pin.setValue(" + pin2 + ")");
                                    //System.out.println("Pin.notifyPin(" + pinNumber + ")");
                                }
                            }
                        }
                    }

                    //System.out.println("Pin Input Value: " + params[0] + " - " + params[1]);
                    //System.out.println("Pin Input Value: " + params[0] + " - " + params[1]);
                    command = 0;
                    counter = 0;
                    needParams = 0;
                }
            }

        } else {

            if (cc == 0x90) {
                // Digital Input
                command = cc;
                needParams = 2;
                counter = 0;
            } else if (cc == 0xF0) {
                // START_SYSEX
                command = cc;
                needParams = -1;
                counter = 0;
                System.out.println("START_SYSEX");
            } else if (cc >= 0xE0 && cc <= (0xE0 + 10)) {
                // Analog Input
                command = cc;
                needParams = 2;
                counter = 0;
            } else if (cc == 0xF9) {
                // Version
                command = cc;
                needParams = -1;
                counter = 0;
            }
            //System.out.println("Empfangen: " + cc + " - " + (char) cc);
        }

    }

    public void getCommand(String commando, Object value) {

        if (value instanceof VS1DByte) {
            VS1DByte values = (VS1DByte) value;

            if (commando.equals("BYTESRECEIVED")) {

            }
        }

        if (value instanceof Integer) {
            Integer input_value = (Integer) value;
            //System.out.println("COMMAND : "+commando);

            if (commando.equals("SINGLEBYTE")) {
                processIn(input_value);
            }

        }

    }

    public void process() {

        if (debug) {
            System.out.println("in.length=" + in.length);
        }

        for (int i = 0; i < in.length; i++) {

            int pinNumber = inPinNumbers[i];
            String pinType = inPinType[i];

            if (pinType.equalsIgnoreCase("DIGITAL_OUTPUT")) {
                if (in[i] instanceof VSBoolean) {
                    VSBoolean value = (VSBoolean) in[i];
                    boolean inputPin = value.getValue();

                    if (inputPin == true) {
                        if (debug) {
                            System.out.println("digitalWrite(" + pinNumber + ", " + 0 + ");");
                        }
                        digitalWrite(pinNumber, 1);
                    } else {
                        if (debug) {
                            System.out.println("digitalWrite(" + pinNumber + ", " + 1 + ");");
                        }
                        digitalWrite(pinNumber, 0);
                    }
                }
            }

            if (pinType.equalsIgnoreCase("PWM_OUTPUT")) {
                if (in[i] instanceof VSInteger) {
                    VSInteger value = (VSInteger) in[i];
                    int inputPin = value.getValue();

                    if (debug) {
                        System.out.println("PWM analogWrite(" + pinNumber + ", " + inputPin + ");");
                    }
                    analogWrite(pinNumber, inputPin);

                }
            }

            if (pinType.equalsIgnoreCase("SERVO_OUTPUT")) {
                if (in[i] instanceof VSInteger) {
                    VSInteger value = (VSInteger) in[i];
                    int inputPin = value.getValue();

                    if (debug) {
                        System.out.println("SERVO analogWrite(" + pinNumber + ", " + inputPin + ");");
                    }
                    analogWrite(pinNumber, inputPin);

                }
            }

        }

    }

    @Override
    public void loadFromStream(java.io.FileInputStream fis) {
        textVar.loadFromStream(fis);
        comport.loadFromStream(fis);                
        baud.loadFromStream(fis);
        bits.loadFromStream(fis);
        parity.loadFromStream(fis);
        stopBits.loadFromStream(fis);
        
        init();

        // propertyChanged(showGraphs);
        //processOutCharts();
    }

    @Override
    public void saveToStream(java.io.FileOutputStream fos) {

        textVar.saveToStream(fos);
        comport.saveToStream(fos);
        baud.saveToStream(fos);
        bits.saveToStream(fos);
        parity.saveToStream(fos);
        stopBits.saveToStream(fos);
    }
}
